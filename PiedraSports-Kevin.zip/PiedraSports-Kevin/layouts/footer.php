<footer class="site-footer border-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5 mb-lg-0">
            <div class="row">
              <div class="col-md-12">
                <h3 class="footer-heading mb-4">Compañia</h3>
              </div>
              <div class="col-md-6 col-lg-4">
                <ul class="list-unstyled">
                  <li><a href="#">Nosotros</a></li>
                  <li><a href="#">Nuestro servidos</a></li>
                  <li><a href="#">Politica de privacidad</a></li>
                  <li><a href="#">afiliate</a></li>
                </ul>
              </div>
              
              <div class="col-md-6 col-lg-4">
                <ul class="list-unstyled">
                  <li><a href="#">Preguntas</a></li>
                  <li><a href="#">Compras</a></li>
                  <li><a href="#">Envios</a></li>
                  <li><a href="#">Estatus de orden</a></li>
                  <li><a href="#">Pago</a></li>                 
              </div>
              <div class="col-md-6 col-lg-4">
                <ul class="list-unstyled">
                  <li><a href="#">Computadores</a></li>
                  <li><a href="#">Consolas</a></li>
                  <li><a href="#">Audifonos</a></li>
                  <li><a href="#">Monitores</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="block-5 mb-5">
              <h3 class="footer-heading mb-4">Informacion De Contacto</h3>
              <ul class="list-unstyled">
                <li class="address">203 Fake St. Mountain View, San Francisco, California, USA</li>
                <li class="phone"><a href="tel://23923929210">+57 3222141516</a></li>
                <li class="email">PiedraSports@gmail.com</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          
        </div>
      </div>
    </footer>